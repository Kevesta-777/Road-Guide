/*
 *  Licensed to GraphHopper GmbH under one or more contributor
 *  license agreements. See the NOTICE file distributed with this work for
 *  additional information regarding copyright ownership.
 *
 *  GraphHopper GmbH licenses this file to you under the Apache License,
 *  Version 2.0 (the "License"); you may not use this file except in
 *  compliance with the License. You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package com.graphhopper.routing.util.tour;

import java.util.Random;

/**
 * Generate only a single points
 *
 * @author Robin Boldt
 */
public class SinglePointTour extends TourStrategy {
    public SinglePointTour(Random random, double distanceInMeter) {
        super(random, distanceInMeter);
    }

    @Override
    public int getNumberOfGeneratedPoints() {
        return 1;
    }

    @Override
    public double getDistanceForIteration(int iteration) {
        return slightlyModifyDistance(overallDistance / 3);
    }

    @Override
    public double getHeadingForIteration(int iteration) {
        return random.nextInt(360);
    }
}
